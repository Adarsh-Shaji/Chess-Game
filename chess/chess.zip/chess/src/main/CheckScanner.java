package main;

import pieces.King;
import pieces.Piece;

public class CheckScanner {

    Board board;

    public CheckScanner(Board board)
    {
        this.board = board;

    }

    public boolean isKingChecked( Move move)
    {
        Piece king =board.findking(move.piece.iswhite);
        assert  king !=null;

        int kingCol = king.col;
        int kingRow = king.row;

                if(board.selectedPiece !=null && board.selectedPiece.name.equals("King"))
                {
                    kingCol = move.newCol;
                    kingRow = move.newRow;
                }
        return  hitByRook(move.newCol, move.newRow,king,kingCol,kingRow , 0 ,1)||  //up
                hitByRook(move.newCol, move.newRow,king,kingCol,kingRow,1,0)||    //right
                hitByRook(move.newCol, move.newRow,king,kingCol,kingRow,0,-1)||   //down
                hitByRook(move.newCol, move.newRow,king,kingCol,kingRow,-1,0)||     //left


                hitByBishop(move.newCol, move.newRow,king,kingCol,kingRow,-1,-1)||   //up left
                hitByBishop(move.newCol, move.newRow,king,kingCol,kingRow,1,-1)||     //up right
                hitByBishop(move.newCol, move.newRow,king,kingCol,kingRow,1,1)||    //down right
                hitByBishop(move.newCol, move.newRow,king,kingCol,kingRow,-1,1)||      //down left

                hitByKnight(move.newCol, move.newRow,king,kingCol,kingRow)||
                hitByPawn(move.newCol, move.newRow,king,kingCol,kingRow)  ||
                hitByKing(king , kingCol , kingRow);

    }

    private boolean hitByRook(int col , int row , Piece king , int kingcol , int kingrow , int colVal , int rowVal)
    {
        for (int i = 1; i < 8; i++) {

            if(kingcol + (i*colVal) == col && kingrow + (i * rowVal) == row)
            {
                break;
            }

            Piece piece = board.getpiece(kingcol +(i*colVal), kingrow + (i*rowVal));
            if(piece !=null && piece!=board.selectedPiece)
            {
                if(!board.sameTeam(piece,king) && (piece.name.equals("Rook") || piece.name.equals("Queen"))) {
                    return true;
                }
                break;
            }

        }

        return false;
    }

    private boolean hitByBishop(int col , int row , Piece king , int kingcol , int kingrow , int colVal , int rowVal)
    {
        for (int i = 1; i < 8; i++) {

            if(kingcol - (i*colVal) == col && kingrow - (i * rowVal) == row)
            {
                break;
            }

            Piece piece = board.getpiece(kingcol -(i*colVal), kingrow - (i*rowVal));
            if(piece !=null && piece!=board.selectedPiece)
            {
                if(!board.sameTeam(piece,king) && (piece.name.equals("Bishop") || piece.name.equals("Queen"))) {
                    return true;
                }
                break;
            }

        }

        return false;
    }

    private  boolean hitByKnight(int col , int row ,Piece king , int kingcol, int kingRow)
    {
        return  checkKnight(board.getpiece(kingcol-1,kingRow-2),king , col , row) ||
                checkKnight(board.getpiece(kingcol+1,kingRow-2),king , col , row) ||
                checkKnight(board.getpiece(kingcol+2,kingRow-1),king , col , row) ||
                checkKnight(board.getpiece(kingcol+2,kingRow+1),king , col , row) ||
                checkKnight(board.getpiece(kingcol+1,kingRow+2),king , col , row) ||
                checkKnight(board.getpiece(kingcol-1,kingRow+2),king , col , row) ||
                checkKnight(board.getpiece(kingcol-2,kingRow+1),king , col , row) ||
                checkKnight(board.getpiece(kingcol-2,kingRow-1),king , col , row);
    }

    private boolean checkKnight(Piece p , Piece k , int col , int row)
    {
        return p!=null && !board.sameTeam(p,k) && p.name.equals("Knight") && !(p.col == col && p.row ==row);
    }

    private  boolean hitByKing(Piece king , int kingcol , int kingrow)
    {
        return  checkKing(board.getpiece(kingcol -1 , kingrow -1),king)||
                checkKing(board.getpiece(kingcol +1 , kingrow -1),king)||
                checkKing(board.getpiece(kingcol  , kingrow -1),king)||
                checkKing(board.getpiece(kingcol -1 , kingrow ),king)||
                checkKing(board.getpiece(kingcol +1 , kingrow ),king)||
                checkKing(board.getpiece(kingcol -1 , kingrow +1),king)||
                checkKing(board.getpiece(kingcol +1 , kingrow +1),king)||
                checkKing(board.getpiece(kingcol  , kingrow +1),king);
    }

    private boolean checkKing(Piece p , Piece k)
    {
        return  p!=null && !board.sameTeam(p,k) && p.name.equals("King");
    }

    private boolean hitByPawn(int col , int row , Piece king , int kingcol , int kingrow)
    {
        int colorval = king.iswhite? -1:1;
        return checkPawn(board.getpiece(kingcol +1 , kingrow +colorval),king,col,row)||
                checkPawn(board.getpiece(kingcol -1 , kingrow +colorval),king,col,row);
    }

    private boolean checkPawn(Piece p , Piece k , int col , int row)
    {
        return p!=null && !board.sameTeam(p,k) && p.name.equals("Pawn") ;
    }
}
